package com.example.msa.springboot.messageq;

import com.example.msa.springboot.repository.ICoffeeStatusMapper;
import com.example.msa.springboot.repository.dvo.OrderStatusDVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {

    @Autowired
    ICoffeeStatusMapper iCoffeeStatusMapper;

    @RefreshScope
    @KafkaListener(topics = "${msaconfig.topic-name}")
    public void processMessage(String kafkaMessage) {

        System.out.println("kafkaMessage : =====> " + kafkaMessage);

        OrderStatusDVO orderStatusDVO = new OrderStatusDVO();
        orderStatusDVO.setOrderHistory(kafkaMessage);

        iCoffeeStatusMapper.insertCoffeeOrderStatus(orderStatusDVO);
    }
}