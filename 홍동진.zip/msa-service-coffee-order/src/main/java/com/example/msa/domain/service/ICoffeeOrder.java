package com.example.msa.domain.service;

import com.example.msa.domain.model.CoffeeOrderCVO;

public interface ICoffeeOrder {

    public String coffeeOrder(CoffeeOrderCVO coffeeOrderCVO);
}
